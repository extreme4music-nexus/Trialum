INTERNAL TRIALUM v33 TRANSLATION SOURCE PACKAGE — NOT AN AUTO INSTALLER
1. Do not overwrite existing .env, compose.yaml, compose.push.yaml,
   DB, Caddy, ports, secrets, /models or private user data.
2. Private root/operator backup of existing API source/Compose and
   a verified PostgreSQL dump + isolated restore are prerequisites.
3. These are source modules and a separate optional translator image
   definition, NOT downloaded model files.
4. Before enabling: install and license-review four pinned offline
   Helsinki-NLP OPUS translation weights; test real MK/SQ -> EN ->
   MK/SQ reference phrases and bench RAM/CPU on the private server.
5. Use .env with TRIALUM_TRANSLATION_ENABLED=false until QA passes.
   Private worker endpoint is http://trialum-translator:5000/translate.
   Compose must include both compose.translation.yaml and
   compose.lwd-translation.env.yaml as final overrides.
6. The existing production v32 AI service is already live; don't
   overwrite it without careful rollback and verified API health.
7. No new public ports, no new SQL migration, no public Play release.
